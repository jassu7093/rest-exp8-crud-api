// models/studentModel.js
const mongoose = require('mongoose');

// Student Schema
const studentSchema = new mongoose.Schema({
  name: { type: String, required: true },
  course: { type: String, required: true },
  age: { type: Number, required: true },
  joinedAt: { type: Date, default: Date.now }
});

// Export Model
module.exports = mongoose.model('Student', studentSchema);
